require "pry"

class Myclass 
	attr_reader :title
	attr_reader :author
	attr_reader :price
	def initialize (title="Unknown", author="Unknown", price=0.0)
		@title = title
		@author = author
		@price = Float(price)
	end

	def ==(other)
		if other.class == Myclass
			@author == other.author && @title == other.title && @price == other.price
		else
			false
		end
	end

	# def title
	# 	@title
	# end

	# def title=(value)
	# 	@title = value
	# end

	# def author
	# 	@author
	# end

	# def author=(value)
	# 	@author = value
	# end

	# def price
	# 	@price
	# end

	# def price=(value)
	# 	@price = value
	# end

	def to_s
		"Title: #{@title}\tAuthor: #{@author}\tPrice: #{@price}"
	end
end

c = Myclass.new
d = Myclass.new


binding.pry